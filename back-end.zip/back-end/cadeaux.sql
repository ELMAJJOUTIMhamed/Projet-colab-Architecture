CREATE TABLE `LISTE_CADEAUX`.`CADEAUX` (
    `ID` INT NOT NULL,
    `IMAGE_URL` VARCHAR(150) NOT NULL,
    `NOM` VARCHAR(45) NOT NULL,
    `PRIX` REAL NOT NULL,
    `DATE_LIMITE_DE_RESERVATION` DATE NOT NULL,
    `STATUS` INT NULL,
    `DESCRIPTION` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`ID`)
) COMMENT = 'Table correspondant au cadeaux pouvant être réservés';

INSERT INTO `LISTE_CADEAUX`.`CADEAUX`(
    ID,
    IMAGE_URL,  -- Correction : Utiliser le même nom de colonne que dans la création de la table
    NOM,
    PRIX,
    DATE_LIMITE_DE_RESERVATION,
    STATUS,
    DESCRIPTION
) VALUES (
    1, 
    '/images/cadeau/roses.png',
    'Bouquet de roses rouges',
    25.99,
    '2023-02-14',
    5,
    'Magnifique bouquet de roses rouges, parfait pour exprimer votre amour le jour de la Saint-Valentin.'
),
(
    2, 
    '/images/cadeau/collier.png',
    'Collier en argent',
    59.99,
    '2023-03-08',
    20,
    'Élégant collier en argent avec un charmant pendentif en forme de cœur, le cadeau idéal pour célébrer la Journée internationale des femmes.'
),
(
    3, 
    '/images/cadeau/bouffe.webp',
    'Panier-cadeau gourmand',
    39.99,
    '2023-04-20',
    15,
    'Découvrez un assortiment délicieux de gourmandises avec ce panier-cadeau gourmet, parfait pour toutes les occasions spéciales.'
),
(
    4, 
    '/images/cadeau/montre.png',
    'Montre élégante en cuir',
    79.99,
    '2023-05-15',
    0,
    'Une montre élégante avec un bracelet en cuir, ajoutant une touche de sophistication à votre style.'
),
(
    5, 
    '/images/cadeau/thé.png',
    'Ensemble de thé artisanal',
    29.99,
    '2023-06-10',
    0,
    'Savourez des moments de détente avec cet ensemble de thé artisanal, parfait pour les amateurs de thé.'
),
(
    6, 
    '/images/cadeau/robe.webp',
    'Robe princesse enfant',
    71.75,
    '2023-07-02',
    0,
    'Offrez à votre petite princesse une magnifique robe pour la faire se sentir spéciale lors des occasions spéciales.'
),
(
    7,
    '/images/cadeau/tablette.webp',
    'Tablette tactile dernière génération',
    199.99,
    '2023-08-18',
    0,
    'Explorez le monde numérique avec la dernière tablette tactile, offrant des performances exceptionnelles et une expérience utilisateur immersive.'
),
(
    8,
    '/images/cadeau/cuisine.jpg',
    'Cours de cuisine avec un chef étoilé',
    89.99,
    '2023-09-25',
    0,
    "Apprenez l'art de la cuisine avec un chef étoilé lors de ce cours de cuisine exclusif, une expérience culinaire inoubliable."
),
(
    9,
    '/images/cadeau/echarpe.jpg',
    'Écharpe en laine faite à la main',
    34.99,
    '2023-10-12',
    0,
    'Restez au chaud avec cette écharpe en laine faite à la main, alliant style et confort.'
),
(
    10,
    '/images/cadeau/spa.jpg',
    'Soin spa et massage relaxant',
    69.99,
    '2023-11-30',
    0,
    'Offrez-vous une journée de détente totale avec ce soin spa et massage relaxant, parfait pour éliminer le stress et les tensions.'
);