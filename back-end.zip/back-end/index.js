const express = require('express');
const mysql2 = require('mysql2');
const cors = require('cors');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
const app = express();
const { v4: uuidv4 } = require('uuid');
const port = 4000;

// Configuration de la connexion à la base de données
const db = mysql2.createConnection({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  port: process.env.DB_PORT || 3306,
  password: process.env.DB_PASSWORD || 'Demonone@12345',
  database: process.env.DB_DATABASE || 'liste_cadeaux',
});

// CORS configuration
app.use(
  cors({
    origin: 'http://localhost:3000',
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    credentials: true,
  })
);

// Connectez-vous à la base de données
db.connect(err => {
  if (err) {
    console.error('Erreur de connexion à la base de données:', err);
  } else {
    console.log('Connecté à la base de données MySQL');
  }
});

// Middleware for parsing JSON requests
app.use(bodyParser.json());

// Helper function for executing SQL queries
async function query(sql, params) {
  return new Promise((resolve, reject) => {
    db.query(sql, params, (err, results) => {
      if (err) {
        reject(err);
      } else {
        resolve(results);
      }
    });
  });
}

// Define a route for user registration
app.post('/api/register', async (req, res) => {
  const { username, password, email } = req.body;
  try {
    // Check if the username is already taken
    const usernameExists = await query('SELECT * FROM `liste_cadeaux`.autheurs WHERE username = ?', [username]);

    if (usernameExists.length > 0) {
      return res.status(400).json({ error: 'Username already exists' });
    }

    // Hash the password before storing it in the database
    const hashedPassword = await bcrypt.hash(password, 10);

    // Generate a random UUID as the user ID
    const userId = uuidv4();

    // Insert the new user into the database
    const insertResult = await query('INSERT INTO `liste_cadeaux`.autheurs (id, username, email, password) VALUES (?, ?, ?, ?)', [
      parseInt(userId.substring(0, 8), 16),
      username,
      email,
      hashedPassword,
    ]);

    return res.json({ message: 'Registration successful', userId });
  } catch (error) {
    console.error('Error during registration:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});
 
// Define a route for user authentication
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    // Query the database to get the hashed password for the provided username
    const results = await query('SELECT * FROM `liste_cadeaux`.autheurs WHERE username = ?', [username]);

    if (results.length === 0) {
      // User not found
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    const hashedPassword = results[0].password;

    // Compare the provided password with the stored hashed password
    const passwordMatch = await bcrypt.compare(password, hashedPassword);

    if (passwordMatch) {
      // Passwords match, authentication successful
      return res.json({ message: 'Login successful' });
    } else {
      // Passwords don't match
      return res.status(401).json({ error: 'Invalid username or password' });
    }
  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Define a route to retrieve all products
app.get('/products', cors(), async (req, res) => {
  try {
    // Execute a SELECT query
    const results = await query('SELECT * FROM liste_cadeaux.cadeaux');
    res.json(results);
  } catch (error) {
    console.error('Error executing query:', error);
    res.status(500).send('Internal server error');
  }
});

// Define a route to retrieve a product by its ID
app.get('/products/:id', cors(), async (req, res) => {
  const userId = req.params.id;

  try {
    // Execute a SELECT query with a parameter
    const results = await query('SELECT * FROM cadeaux WHERE id = ?', [userId]);

    if (results.length > 0) {
      res.json(results[0]);
    } else {
      res.status(404).send('User not found');
    }
  } catch (error) {
    console.error('Error executing query:', error);
    res.status(500).send('Internal server error');
  }
});

// Port d'écoute du serveur
app.listen(port, () => {
  console.log(`Serveur écoutant sur le port ${port}`);
});
