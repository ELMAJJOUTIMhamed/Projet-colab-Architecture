const axios = require('axios');
const { expect } = require('chai');

const apiUrl = 'http://localhost:4000';

// Sample data for testing POST /api/login
const validCredentials = {
  username: 'root',
  password: 'root',
};

// Sample invalid credentials for negative testing
const invalidCredentials = {
  username: 'testuser',
  password: 'wrongpassword',
};

// Sample data for testing POST /api/register
const newUser = {
  username: 'newUser123',
  password: 'password123',
  email: 'newuser@example.com',
};

describe('API Tests', function () {
  // Test POST /api/login
  describe('POST /api/login', function () {
    it('should return a success message with valid credentials', async function () {
      const response = await axios.post(`${apiUrl}/api/login`, validCredentials);
      expect(response.status).to.equal(200);
      expect(response.data).to.have.property('message').that.equals('Login successful');
    });

    it('should return an error with invalid credentials', async function () {
      try {
        await axios.post(`${apiUrl}/api/login`, invalidCredentials);
      } catch (error) {
        expect(error.response.status).to.equal(401);
        expect(error.response.data).to.have.property('error').that.equals('Invalid username or password');
      }
    });
  });

  // Test POST /api/register
  describe('POST /api/register', function () {
    // Test registration with valid credentials
    it('should return a success message with valid registration', async function () {
      const response = await axios.post(`${apiUrl}/api/register`, newUser);
      expect(response.status).to.equal(200);
      expect(response.data).to.have.property('message').that.equals('Registration successful');
      expect(response.data).to.have.property('userId').that.is.a('number');
    });

    // Test registration with an already taken username
    it('should return an error with an already taken username', async function () {
      try {
        await axios.post(`${apiUrl}/api/register`, newUser);
      } catch (error) {
        expect(error.response.status).to.equal(400);
        expect(error.response.data).to.have.property('error').that.equals('Username already exists');
      }
    });

    // Test registration with incomplete data
    it('should return an error with incomplete data', async function () {
      const incompleteUser = {
        username: 'incompleteUser',
        password: 'password123',
        // Missing email field
      };

      try {
        await axios.post(`${apiUrl}/api/register`, incompleteUser);
      } catch (error) {
        expect(error.response.status).to.equal(500); // Adjust this based on your actual error handling
      }
    });
  });

  // Test GET /products
  describe('GET /products', function () {
    it('should return an array of products', async function () {
      const response = await axios.get(`${apiUrl}/products`);
      expect(response.status).to.equal(200);
      expect(response.data).to.be.an('array');
    });
  });

  // Test GET /products/:id
  describe('GET /products/:id', function () {
    it('should return a product with a specific ID', async function () {
      const productId = 1; // Replace with a valid product ID from your database
      const response = await axios.get(`${apiUrl}/products/${productId}`);
      expect(response.status).to.equal(200);
      expect(response.data).to.be.an('object');
      // You can add more specific assertions based on your data structure
    });

    it('should return a 404 error for an invalid product ID', async function () {
      const invalidProductId = 9999; // Replace with an invalid product ID
      try {
        await axios.get(`${apiUrl}/products/${invalidProductId}`);
      } catch (error) {
        expect(error.response.status).to.equal(404);
        expect(error.response.data).to.equal('User not found');
      }
    });
  });
});
