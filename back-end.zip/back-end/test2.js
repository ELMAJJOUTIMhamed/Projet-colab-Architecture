const bcrypt = require('bcrypt')
password = 'root'
hashedPassword = '$2b$10$ai7TsHVXXs3SGg4UrW.MTefnkXZqjJLPik4nSO8KJBSv3QCYzs7U2'
const passwordMatch =  bcrypt.compare(password, hashedPassword);

passwordMatch.then(function(password) {console.log(password)});